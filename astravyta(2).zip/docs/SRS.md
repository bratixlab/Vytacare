# ASTRAVYTA: Software Requirements Summary

Prototype targets are engineering goals, not NASA-certified standards. Not for clinical use.

## Roles
| Role | Permissions |
|---|---|
| Astronaut | Record and view personal health data, complete assessments, view alerts |
| Medical Officer | Review assigned records, assess alerts, document interventions |
| Mission Administrator | Manage missions, users, settings, authorized mission summaries. No automatic access to sensitive medical detail |

## Functional requirements
- FR-01..05 Profiles and baselines: registration, astronaut profile, approved baseline, mission assignment, health history
- FR-06..12 Monitoring: heart rate, blood pressure, SpO2, sleep, mood/stress, activity, bone-health indicators
- FR-13..19 Hybrid engine: Engine A rule-based (limits + personal baseline, names the rule), Engine B anomaly detection (anomaly, data points, confidence, explanation, suggested review). Confidence is never a diagnosis probability
- FR-20..25 Offline-first: offline access, local recording, local analysis, local alerts, sync, safe conflict handling
- FR-26..30 Reporting: daily summary, charts, alert history, Medical Officer comments, exportable reports

## Non-functional targets
Core features offline; local alert under 2 s; encrypted transport and local data; no silent data loss; audit of important actions; multi-astronaut and multi-mission support.

## NASA HRP risk coverage
See the Risk coverage page in the app (17 risks mapped to full / partial / record-only).

## Challenge brief coverage (NASA Space Apps 2026)
- Body map (clickable systems), daily check-in with symptoms, indicator guide with measurement instructions
- Blood glucose added alongside blood pressure, heart rate, temperature, sleep and mood
- Mission routine: prompts, XP, levels, streaks, badges
- Environment selector (space station, deep-space transit, lunar base, Mars surface) with message-delay and autonomy guidance
- Configured limits (Engine A) are prototype examples; real limits come from the mission flight surgeon
- Not implemented yet: authentication, PostgreSQL persistence in the API, diastolic pressure field, camera/wearable input, PDF export

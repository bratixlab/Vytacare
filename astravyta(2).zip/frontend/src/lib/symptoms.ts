import type { Alert } from "./types";

export interface Symptom { id: string; label: string; red: boolean; advice: string; risk: string }

export const SYMPTOMS: Symptom[] = [
  { id: "dizzy", label: "Dizziness or balance problems", red: false, risk: "Altered sensorimotor and vestibular function",
    advice: "Stop moving, hold on to a handrail, and rest. Log how long it lasts and tell the crew. Report it if it returns." },
  { id: "vision", label: "Change in vision", red: false, risk: "Spaceflight-associated neuro-ocular syndrome",
    advice: "Note which eye and what changed (blurry near vision, flashes, shadows). Report it to the flight surgeon the same day." },
  { id: "headache", label: "Headache", red: false, risk: "Hypoxia and closed environment",
    advice: "Check cabin CO₂ and O₂ first. Drink water and rest. Report it if it is severe or lasts more than a day." },
  { id: "nausea", label: "Nausea or vomiting", red: false, risk: "Altered sensorimotor and vestibular function",
    advice: "Sip fluids, rest, and avoid sudden head movements. Report it if it lasts more than a day." },
  { id: "rash", label: "Rash or skin reaction", red: false, risk: "Altered immune system responses",
    advice: "Keep the area clean and take a photo for the flight surgeon. Report it if it spreads or is painful." },
  { id: "palpitations", label: "Racing or irregular heartbeat", red: false, risk: "Cardiovascular adaptations",
    advice: "Sit still, breathe slowly, and repeat your heart rate. Report it if it keeps happening." },
  { id: "bonepain", label: "Bone, back or muscle pain", red: false, risk: "Spaceflight-induced bone changes",
    advice: "Stop the exercise, rest, and log the location. Report pain that lasts more than two days." },
  { id: "lowmood", label: "Low mood or feeling withdrawn", red: false, risk: "Behavioral changes and psychiatric disorders",
    advice: "Talk with a crew member or arrange a private call. Report it to the flight surgeon if it lasts several days." },
  { id: "chestpain", label: "Chest pain or pressure", red: true, risk: "Cardiovascular adaptations",
    advice: "Stop all activity. Alert the crew and contact the flight surgeon now." },
  { id: "faint", label: "Fainting or near-fainting", red: true, risk: "Cardiovascular adaptations",
    advice: "Stay still and secured. Alert the crew and contact the flight surgeon now." },
  { id: "breath", label: "Severe shortness of breath", red: true, risk: "Hypoxia",
    advice: "Check cabin air now and use emergency oxygen if available. Alert the crew and contact the flight surgeon now." },
];

export function symptomAlerts(ids: string[], day: number): Alert[] {
  return ids.flatMap((id) => {
    const s = SYMPTOMS.find((x) => x.id === id);
    if (!s) return [];
    return [{
      id: `S-${id}-${day}`, engine: "S" as const, severity: s.red ? ("critical" as const) : ("warning" as const),
      title: s.red ? `${s.label}: contact the flight surgeon now` : `Reported: ${s.label.toLowerCase()}`,
      why: "Reported by the astronaut in the daily check-in.", action: s.advice, risk: s.risk, keys: [id],
    }];
  });
}

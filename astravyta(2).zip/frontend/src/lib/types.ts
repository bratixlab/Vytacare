export type MetricKey = "hr" | "sys" | "temp" | "spo2" | "glu" | "sleep" | "mood" | "stress" | "ex" | "co2" | "rad";
export type DayReading = Record<MetricKey, number>;
export type Role = "Astronaut" | "Medical Officer" | "Mission Administrator";
export type Severity = "warning" | "critical";

export interface Astronaut {
  id: string;
  name: string;
  scenario: string;
  seed: number;
  base: DayReading;
  drift?: Partial<DayReading>;
  from?: number;
}

export interface Alert {
  id: string;
  engine: "A" | "B" | "S";
  severity: Severity;
  title: string;
  why: string;
  action: string;
  risk: string;
  keys?: string[];
  confidence?: number;
  points?: number[];
}

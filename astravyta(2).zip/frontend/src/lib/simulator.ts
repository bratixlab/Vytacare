import { KEYS, METRICS } from "./metrics";
import type { Astronaut, DayReading } from "./types";

export const DAYS = 14;

export const CREW: Astronaut[] = [
  { id: "A", name: "Cdr. Amara Okafor", scenario: "Nominal", seed: 11,
    base: { hr: 62, sys: 116, temp: 36.6, spo2: 98, glu: 92, sleep: 7.2, mood: 7.8, stress: 3, ex: 120, co2: 2800, rad: 480 } },
  { id: "B", name: "Dr. Li Wei", scenario: "Isolation drift", seed: 22, from: 8,
    drift: { sleep: -0.45, mood: -0.5, stress: 0.55, ex: -9, hr: 0.9 },
    base: { hr: 66, sys: 118, temp: 36.7, spo2: 98, glu: 91, sleep: 7.0, mood: 7.5, stress: 3.5, ex: 110, co2: 2750, rad: 470 } },
  { id: "C", name: "Maj. Sam Ortega", scenario: "Cabin air", seed: 33, from: 10,
    drift: { spo2: -0.55, hr: 1.8, co2: 380, sys: 1.6 },
    base: { hr: 64, sys: 117, temp: 36.6, spo2: 97.8, glu: 93, sleep: 7.1, mood: 7.6, stress: 3.2, ex: 115, co2: 2780, rad: 490 } },
];

function mulberry32(seed: number) {
  let s = seed | 0;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generate(a: Astronaut): DayReading[] {
  const r = mulberry32(a.seed);
  const rows: DayReading[] = [];
  for (let d = 1; d <= DAYS; d++) {
    const row = {} as DayReading;
    for (const k of KEYS) {
      let v = a.base[k] + (r() + r() + r() - 1.5) * 1.6 * METRICS[k].noise;
      const drift = a.drift?.[k];
      if (drift && a.from && d >= a.from) v += drift * (d - a.from + 1);
      row[k] = v;
    }
    row.spo2 = Math.min(100, row.spo2);
    row.mood = Math.max(1, Math.min(10, row.mood));
    row.stress = Math.max(1, Math.min(10, row.stress));
    rows.push(row);
  }
  return rows;
}

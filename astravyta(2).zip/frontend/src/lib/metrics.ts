import type { MetricKey } from "./types";

export interface MetricInfo {
  label: string;
  unit: string;
  group: "Physical" | "Mental" | "Environment";
  risk: string;
  action: string;
  lowIsBad: boolean;
  digits: number;
  noise: number;
  /** Example configured limits. The mission flight surgeon sets the real ones. */
  limit?: { lo?: number; hi?: number };
}

export const METRICS: Record<MetricKey, MetricInfo> = {
  hr: { label: "Heart rate", unit: "bpm", group: "Physical", risk: "Cardiovascular adaptations", lowIsBad: false, digits: 0, noise: 1.5, limit: { lo: 45, hi: 100 },
    action: "Rest, repeat the measurement, and request a Medical Officer review if it persists." },
  sys: { label: "Systolic blood pressure", unit: "mmHg", group: "Physical", risk: "Cardiovascular adaptations", lowIsBad: false, digits: 0, noise: 3, limit: { lo: 90, hi: 140 },
    action: "Re-measure after 5 minutes of rest and log any symptoms." },
  temp: { label: "Body temperature", unit: "°C", group: "Physical", risk: "Altered immune responses", lowIsBad: false, digits: 2, noise: 0.12, limit: { hi: 37.8 },
    action: "Log symptoms and consult the Medical Officer." },
  spo2: { label: "Oxygen saturation", unit: "%", group: "Physical", risk: "Hypoxia", lowIsBad: true, digits: 1, noise: 0.4, limit: { lo: 92 },
    action: "Check cabin O₂ and CO₂, repeat the reading, and alert the Medical Officer." },
  glu: { label: "Blood glucose", unit: "mg/dL", group: "Physical", risk: "Inadequate food and nutrition", lowIsBad: false, digits: 0, noise: 4, limit: { lo: 70, hi: 140 },
    action: "Repeat the fingerstick, treat a low reading per protocol, and report it to the Medical Officer." },
  sleep: { label: "Sleep", unit: "h", group: "Mental", risk: "Inadequate sleep and irregular schedules", lowIsBad: true, digits: 1, noise: 0.3, limit: { lo: 5 },
    action: "Review the schedule, protect the sleep window, and keep a sleep diary." },
  mood: { label: "Mood", unit: "/10", group: "Mental", risk: "Behavioral changes", lowIsBad: true, digits: 1, noise: 0.5,
    action: "Schedule a private conference with the flight surgeon or psychologist." },
  stress: { label: "Stress", unit: "/10", group: "Mental", risk: "Behavioral changes and isolation", lowIsBad: false, digits: 1, noise: 0.5,
    action: "Offer a relaxation protocol and a family video call." },
  ex: { label: "Exercise", unit: "min", group: "Physical", risk: "Bone and muscle loss", lowIsBad: true, digits: 0, noise: 10,
    action: "Resume the resistive exercise plan and track the load." },
  co2: { label: "Cabin CO₂", unit: "ppm", group: "Environment", risk: "Hostile, closed environment", lowIsBad: false, digits: 0, noise: 120, limit: { hi: 5000 },
    action: "Inspect the CO₂ scrubber and ventilation." },
  rad: { label: "Radiation", unit: "µSv/day", group: "Environment", risk: "Radiation-induced cancers", lowIsBad: false, digits: 0, noise: 30,
    action: "Move to the shielded area and log the exposure." },
};

export const KEYS = Object.keys(METRICS) as MetricKey[];
export const fmt = (v: number, k: MetricKey) => v.toFixed(METRICS[k].digits);

export const RISKS: [string, "Full" | "Partial" | "Record", string][] = [
  ["Altered immune system responses", "Partial", "Temperature trend, symptom check, rash log"],
  ["Altered sensorimotor and vestibular function", "Partial", "Dizziness and nausea symptom check"],
  ["Cardiovascular adaptations", "Full", "Heart rate and blood pressure: baseline, limits, trend"],
  ["Decompression sickness", "Record", "Pressure exposure log"],
  ["Host-microorganism interactions", "Record", "Infection symptom log"],
  ["Hypoxia", "Full", "SpO₂ with cabin O₂/CO₂ rules"],
  ["Inadequate food and nutrition", "Partial", "Blood glucose limits and body-map guidance"],
  ["Spacewalk injury and compromised performance", "Record", "Pre-EVA health checklist"],
  ["Reduced cardiorespiratory and musculoskeletal fitness", "Partial", "Exercise minutes, trend and daily routine"],
  ["Spaceflight-associated neuro-ocular syndrome", "Partial", "Vision change symptom check with same-day escalation"],
  ["Spaceflight-induced bone changes", "Partial", "Exercise, bone-pain symptom and nutrition guidance"],
  ["Behavioral changes and psychiatric disorders", "Full", "Mood and stress baselines, trends, combined rule"],
  ["Inadequate teamwork", "Record", "Crew social task in the routine"],
  ["Inadequate sleep and irregular schedules", "Full", "Sleep limits, drift detection"],
  ["Inadequate systems operations support", "Record", "Checklists and support log"],
  ["Injury from dynamic loads", "Record", "Landing injury assessment"],
  ["Radiation-induced cancers", "Partial", "Daily dose log and cumulative dose"],
];

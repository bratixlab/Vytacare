export interface Env {
  id: string;
  name: string;
  blurb: string;
  delay: string;
  autonomous: boolean;
  hazards: { radiation: number; isolation: number; distance: number; gravity: number; closed: number };
  focus: string;
}

export const HAZARDS: [keyof Env["hazards"], string][] = [
  ["radiation", "Space radiation"],
  ["isolation", "Isolation and confinement"],
  ["distance", "Distance from Earth"],
  ["gravity", "Gravity fields"],
  ["closed", "Hostile closed environment"],
];

export const ENVS: Env[] = [
  { id: "station", name: "Space station (low Earth orbit)", delay: "About 1 second", autonomous: false,
    blurb: "Close to Earth with the planet's magnetic field still helping to shield the crew.",
    hazards: { radiation: 1, isolation: 2, distance: 1, gravity: 3, closed: 2 },
    focus: "Bone and muscle loss, fluid shifts and vision changes in microgravity." },
  { id: "transit", name: "Deep-space spacecraft (transit)", delay: "Seconds to many minutes", autonomous: true,
    blurb: "Beyond Earth's magnetic field, in microgravity, with a small crew in a small cabin.",
    hazards: { radiation: 3, isolation: 3, distance: 3, gravity: 3, closed: 3 },
    focus: "Radiation exposure, isolation strain and self-reliance when help is far away." },
  { id: "lunar", name: "Lunar base", delay: "About 1.3 seconds one way", autonomous: false,
    blurb: "Surface habitat with about one-sixth of Earth's gravity and abrasive lunar dust.",
    hazards: { radiation: 3, isolation: 2, distance: 2, gravity: 2, closed: 2 },
    focus: "Radiation, dust in the lungs and eyes, and partial-gravity adaptation." },
  { id: "mars", name: "Mars surface (rover or base)", delay: "4 to 24 minutes one way", autonomous: true,
    blurb: "Long communication delays, about 38% of Earth's gravity, and months from home.",
    hazards: { radiation: 3, isolation: 3, distance: 3, gravity: 2, closed: 3 },
    focus: "Autonomy: you may wait many minutes for ground advice, so decisions start with you." },
];

import type { MetricKey } from "./types";

export interface BodySystem {
  id: string;
  name: string;
  does: string;
  spaceEffect: string;
  metrics: MetricKey[];
  symptoms: string[];
  hazards: string[];
  risks: string[];
  selfCare: string[];
  callGround: string[];
}

export const SYSTEMS: BodySystem[] = [
  { id: "brain", name: "Brain and mind", metrics: ["mood", "stress", "sleep"], symptoms: ["dizzy", "lowmood"],
    does: "Controls thinking, mood, balance and your sleep rhythm.",
    spaceEffect: "Isolation, confinement and irregular light cycles can lower mood and disturb sleep. Fluid shifts can upset balance and cause space motion sickness.",
    hazards: ["Isolation and confinement", "Distance from Earth", "Gravity fields"],
    risks: ["Behavioral changes and psychiatric disorders", "Inadequate sleep and irregular schedules", "Altered sensorimotor and vestibular function", "Inadequate teamwork"],
    selfCare: ["Keep a fixed sleep window and dim the lights before bed", "Arrange a private call or message with family", "Join a crew meal or social activity", "Try slow breathing for five minutes"],
    callGround: ["Low mood or irritability for several days", "Any thoughts of self-harm (contact someone immediately)", "Under 5 hours of sleep for 3 nights"] },
  { id: "eyes", name: "Eyes", metrics: [], symptoms: ["vision"],
    does: "Give you sight. The back of the eye can show pressure changes.",
    spaceEffect: "Fluid shifts toward the head can swell the optic nerve and flatten the back of the eye. This is called spaceflight-associated neuro-ocular syndrome (SANS).",
    hazards: ["Gravity fields"],
    risks: ["Spaceflight-associated neuro-ocular syndrome"],
    selfCare: ["Report any change in near or far vision", "Complete the scheduled eye checks", "Follow the exercise and fluid plan from the flight surgeon"],
    callGround: ["Any new blur, flashes or shadows in vision: same day", "Headache together with vision change"] },
  { id: "heart", name: "Heart and circulation", metrics: ["hr", "sys"], symptoms: ["palpitations", "chestpain", "faint"],
    does: "Pumps blood and oxygen around the body.",
    spaceEffect: "In weightlessness fluid moves toward the chest and head, and the heart does less work. The cardiovascular system deconditions, and standing up after return can cause fainting.",
    hazards: ["Gravity fields", "Space radiation"],
    risks: ["Cardiovascular adaptations"],
    selfCare: ["Do the planned aerobic exercise", "Stay hydrated and follow the fluid plan from the flight surgeon", "Rest, then repeat the measurement after five minutes"],
    callGround: ["Chest pain, fainting or severe breathlessness: immediately", "Resting heart rate above 100 on repeat readings", "Systolic pressure above 140 twice, or below 90 with dizziness"] },
  { id: "lungs", name: "Lungs and oxygen", metrics: ["spo2", "co2"], symptoms: ["breath", "headache"],
    does: "Bring oxygen in and remove carbon dioxide.",
    spaceEffect: "A closed cabin can build up carbon dioxide or lose oxygen. Low oxygen (hypoxia) is dangerous quickly, and early signs are headache, confusion and fast breathing.",
    hazards: ["Hostile closed environment"],
    risks: ["Hypoxia", "Decompression sickness"],
    selfCare: ["Check the cabin O₂ and CO₂ readouts first", "Reduce exertion and breathe slowly", "Repeat the SpO₂ reading with a warm, still finger"],
    callGround: ["SpO₂ below 92 on repeat", "Cabin CO₂ above the mission limit", "Confusion, severe headache or blue lips"] },
  { id: "gut", name: "Metabolism and nutrition", metrics: ["glu"], symptoms: ["nausea"],
    does: "Turns food into energy and keeps blood sugar steady.",
    spaceEffect: "Limited food variety, appetite changes and stress can reduce intake and affect blood sugar. Poor nutrition also weakens bone, muscle and immune function.",
    hazards: ["Isolation and confinement", "Hostile closed environment"],
    risks: ["Inadequate food and nutrition"],
    selfCare: ["Eat regular meals and log them", "Drink water through the day", "Repeat the blood sugar test if a reading looks unusual"],
    callGround: ["Blood sugar below 70 that does not recover after treatment", "Fasting readings above 125 on repeat", "Vomiting that lasts more than a day"] },
  { id: "bones", name: "Bones and muscles", metrics: ["ex"], symptoms: ["bonepain"],
    does: "Support the body and produce movement.",
    spaceEffect: "Without gravity loading, bones lose density and muscles shrink. Exercise is the main protection.",
    hazards: ["Gravity fields"],
    risks: ["Spaceflight-induced bone changes", "Reduced cardiorespiratory and musculoskeletal fitness", "Injury from dynamic loads"],
    selfCare: ["Complete the resistive exercise session", "Eat the protein, calcium and vitamin D in your nutrition plan", "Log any pain during exercise"],
    callGround: ["Bone or back pain that persists", "Exercise well below plan for several days", "Injury during exercise or a spacewalk"] },
  { id: "immune", name: "Immune system and skin", metrics: ["temp"], symptoms: ["rash"],
    does: "Defends against infection and heals tissue.",
    spaceEffect: "Stress, radiation and altered gravity change immune responses. Dormant viruses can reactivate, and rashes or minor infections can be slow to settle.",
    hazards: ["Space radiation", "Isolation and confinement", "Hostile closed environment"],
    risks: ["Altered immune system responses", "Host-microorganism interactions", "Radiation-induced cancers"],
    selfCare: ["Keep skin and hands clean", "Log any new rash or sore", "Protect your sleep and eat well"],
    callGround: ["Temperature of 37.8 °C or above", "A rash that spreads or is painful", "A wound that does not heal"] },
];

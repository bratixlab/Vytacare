import type { Alert } from "./types";

export interface Task { id: string; label: string; detail: string; xp: number; essential: boolean }

export const TASKS: Task[] = [
  { id: "checkin", label: "Daily health check-in", detail: "Log vitals, mood and symptoms.", xp: 30, essential: true },
  { id: "glucose", label: "Blood sugar test", detail: "Fingerstick, noted as fasting or not.", xp: 15, essential: true },
  { id: "exercise", label: "Exercise session", detail: "At least 60 minutes of planned exercise.", xp: 25, essential: true },
  { id: "air", label: "Cabin air and dosimeter check", detail: "Read CO₂ and radiation dose.", xp: 10, essential: true },
  { id: "sleepwin", label: "Protect your sleep window", detail: "Lights down and screens off on time.", xp: 10, essential: false },
  { id: "social", label: "Crew social time or family call", detail: "Eat together or call home.", xp: 15, essential: false },
];

const ESSENTIAL = TASKS.filter((t) => t.essential).map((t) => t.id);
export const dayKey = (crewId: string, day: number) => `${crewId}-${day}`;
export const XP_PER_LEVEL = 150;

export function progress(done: Record<string, string[]>, crewId: string, day: number) {
  const days = Object.keys(done).filter((k) => k.startsWith(`${crewId}-`)).map((k) => Number(k.split("-")[1]));
  let xp = 0, exerciseDays = 0, checkins = 0;
  for (const d of days) {
    const ids = done[dayKey(crewId, d)] ?? [];
    for (const id of ids) xp += TASKS.find((t) => t.id === id)?.xp ?? 0;
    if (ids.includes("exercise")) exerciseDays++;
    if (ids.includes("checkin")) checkins++;
  }
  let streak = 0;
  for (let d = day; d >= 1; d--) {
    const ids = done[dayKey(crewId, d)] ?? [];
    if (ESSENTIAL.every((i) => ids.includes(i))) streak++; else break;
  }
  const badges = [
    { id: "first", label: "First check-in", detail: "Complete one daily check-in", earned: checkins >= 1 },
    { id: "s3", label: "3-day streak", detail: "Finish all essential tasks 3 days running", earned: streak >= 3 },
    { id: "s7", label: "7-day streak", detail: "Finish all essential tasks 7 days running", earned: streak >= 7 },
    { id: "bones", label: "Strong bones", detail: "Exercise on 5 different days", earned: exerciseDays >= 5 },
  ];
  return { xp, level: Math.floor(xp / XP_PER_LEVEL) + 1, into: xp % XP_PER_LEVEL, streak, badges };
}

export function healthScore(alerts: Alert[]) {
  const crit = alerts.filter((a) => a.severity === "critical").length;
  const warn = alerts.length - crit;
  return Math.max(0, Math.min(100, 100 - 18 * crit - 7 * warn));
}

import { del, get, set } from "idb-keyval";

const KEY = "astravyta:queue";

export interface QueuedRecord {
  id: string;
  astronaut: string;
  day: number;
  severity: string;
  message: string;
  createdAt: string;
}

export async function getQueue(): Promise<QueuedRecord[]> {
  return (await get<QueuedRecord[]>(KEY)) ?? [];
}

export async function enqueue(r: QueuedRecord): Promise<number> {
  const q = await getQueue();
  if (!q.some((x) => x.id === r.id)) {
    q.push(r);
    await set(KEY, q);
  }
  return q.length;
}

/** Sends queued records to the API. Keeps them locally if the API is unreachable (no silent loss). */
export async function flush(): Promise<{ sent: number; ok: boolean }> {
  const q = await getQueue();
  if (!q.length) return { sent: 0, ok: true };
  try {
    const res = await fetch("/api/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ records: q }),
    });
    if (!res.ok) throw new Error(String(res.status));
    await del(KEY);
    return { sent: q.length, ok: true };
  } catch {
    return { sent: 0, ok: false };
  }
}

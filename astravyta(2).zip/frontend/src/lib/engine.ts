import { METRICS, KEYS, fmt } from "./metrics";
import type { Alert, DayReading, MetricKey } from "./types";

export const BASE_DAYS = 7;

export function baseline(rows: DayReading[], k: MetricKey) {
  const v = rows.slice(0, BASE_DAYS).map((r) => r[k]);
  const mean = v.reduce((s, x) => s + x, 0) / v.length;
  const sd = Math.sqrt(v.reduce((s, x) => s + (x - mean) ** 2, 0) / v.length);
  return { mean, sd: Math.max(sd, METRICS[k].noise * 1.0) };
}

/** Engine A: configured limits plus personal-baseline rules (z >= 2 with a worsening trend, or z >= 3). */
export function ruleAlerts(rows: DayReading[], day: number): Alert[] {
  const out: Alert[] = [];
  const hit = new Set<MetricKey>();
  for (const k of KEYS) {
    const m = METRICS[k];
    const { mean, sd } = baseline(rows, k);
    const cur = rows[day - 1][k];
    const z = (cur - mean) / sd;

    const lim = m.limit;
    const outside = !!lim && ((lim.lo !== undefined && cur < lim.lo) || (lim.hi !== undefined && cur > lim.hi));
    if (outside && lim) {
      hit.add(k);
      const parts: string[] = [];
      if (lim.lo !== undefined) parts.push(`at least ${lim.lo}`);
      if (lim.hi !== undefined) parts.push(`at most ${lim.hi}`);
      out.push({
        id: `A-${k}-${day}`, engine: "A", severity: "critical", risk: m.risk, keys: [k],
        title: `${m.label} is ${fmt(cur, k)} ${m.unit}, outside the configured limit`,
        why: `Limit: ${parts.join(" and ")} ${m.unit}. Personal baseline: ${fmt(mean, k)} ± ${fmt(sd, k)} ${m.unit}. These limits are prototype examples; the mission flight surgeon sets the real ones.`,
        action: `${m.action} Contact the flight surgeon.`,
      });
      continue;
    }

    const bad = m.lowIsBad ? -z : z;
    const last3 = rows.slice(Math.max(0, day - 3), day).map((r) => r[k]);
    const trend = last3[last3.length - 1] - last3[0];
    const worse = m.lowIsBad ? trend < 0 : trend > 0;
    if (bad >= 2 && (worse || bad >= 3)) {
      hit.add(k);
      let since = day;
      for (let d = day; d > BASE_DAYS; d--) {
        const zz = (rows[d - 1][k] - mean) / sd;
        if ((m.lowIsBad ? -zz : zz) >= 2) since = d; else break;
      }
      out.push({
        id: `A-${k}-${day}`, engine: "A", severity: bad >= 3.5 ? "critical" : "warning", risk: m.risk, keys: [k],
        title: `${m.label} is ${fmt(cur, k)} ${m.unit}, ${cur > mean ? "above" : "below"} personal baseline`,
        why: `Baseline ${fmt(mean, k)} ± ${fmt(sd, k)} ${m.unit} (z = ${z.toFixed(1)}). Outside the normal range since day ${since}; change over the last 3 days: ${trend >= 0 ? "+" : ""}${fmt(trend, k)} ${m.unit}.`,
        action: m.action + (bad >= 3.5 ? " Escalate to the Medical Officer or ground flight surgeon." : ""),
      });
    }
  }
  const combos: Alert[] = [];
  if (["hr", "spo2", "co2"].filter((k) => hit.has(k as MetricKey)).length >= 2)
    combos.push({ id: `A-air-${day}`, engine: "A", severity: "critical", risk: "Hypoxia and closed environment", keys: ["hr", "spo2", "co2"],
      title: "Heart rate up, SpO₂ down and cabin CO₂ high",
      why: "Several related indicators moved together. This pattern is consistent with possible hypoxia or hypercapnia exposure.",
      action: "Run a cabin air check now, follow the emergency oxygen protocol if available, and notify the Medical Officer." });
  if (["sleep", "mood", "stress"].filter((k) => hit.has(k as MetricKey)).length >= 2)
    combos.push({ id: `A-mind-${day}`, engine: "A", severity: "critical", risk: "Behavioral changes and sleep", keys: ["sleep", "mood", "stress"],
      title: "Poor sleep, lower mood and higher stress",
      why: "Two or more mental-health indicators moved in the adverse direction. This pattern is consistent with isolation strain.",
      action: "Offer a private psychological support session, adjust the workload, and schedule a crew social activity." });
  return [...combos, ...out];
}

/** Engine B: multi-day trend model. Confidence is pattern strength, not a diagnosis probability. */
export function anomalyFindings(rows: DayReading[], day: number): Alert[] {
  const out: Alert[] = [];
  if (day <= BASE_DAYS) return out;
  for (const k of ["hr", "sleep", "mood", "stress", "ex"] as MetricKey[]) {
    const m = METRICS[k];
    const n = Math.min(5, day);
    const y = rows.slice(day - n, day).map((r) => r[k]);
    const xm = (n - 1) / 2;
    const ym = y.reduce((s, v) => s + v, 0) / n;
    let nu = 0, de = 0;
    y.forEach((v, i) => { nu += (i - xm) * (v - ym); de += (i - xm) ** 2; });
    const slope = nu / de;
    const { sd } = baseline(rows, k);
    const drift = (slope * (n - 1)) / sd;
    const bad = m.lowIsBad ? -drift : drift;
    if (bad >= 3)
      out.push({
        id: `B-${k}-${day}`, engine: "B", severity: "warning", risk: m.risk, points: y, keys: [k],
        confidence: Math.min(0.95, 0.4 + bad / 10),
        title: `${m.label} is trending ${slope > 0 ? "up" : "down"} (${slope > 0 ? "+" : ""}${fmt(slope, k)} ${m.unit} per day)`,
        why: `The ${n}-day slope is several times larger than this astronaut's normal day-to-day variation.`,
        action: m.action,
      });
  }
  return out;
}

import { get, set } from "idb-keyval";

export async function load<T>(key: string, fallback: T): Promise<T> {
  try { return (await get<T>(key)) ?? fallback; } catch { return fallback; }
}

export async function save(key: string, value: unknown): Promise<void> {
  try { await set(key, value); } catch { /* storage unavailable: keep running */ }
}

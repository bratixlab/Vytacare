import { useEffect, useMemo, useState } from "react";
import Sidebar, { type Tab } from "./components/Sidebar";
import { anomalyFindings, BASE_DAYS, ruleAlerts } from "./lib/engine";
import { ENVS } from "./lib/environments";
import { enqueue, flush, getQueue } from "./lib/offline";
import { CREW, generate } from "./lib/simulator";
import { load, save } from "./lib/storage";
import { symptomAlerts } from "./lib/symptoms";
import { dayKey, progress, TASKS } from "./lib/tasks";
import type { DayReading, Role } from "./lib/types";
import BodyMap from "./pages/BodyMap";
import CheckIn from "./pages/CheckIn";
import Coverage from "./pages/Coverage";
import Dashboard from "./pages/Dashboard";
import Guide from "./pages/Guide";
import Reports from "./pages/Reports";
import Routine from "./pages/Routine";

const ROLES: Role[] = ["Astronaut", "Medical Officer", "Mission Administrator"];
const field = "rounded-md border border-line bg-panel px-3 py-2 text-sm";

function Restricted({ title }: { title: string }) {
  return (
    <div>
      <h1 className="text-3xl font-bold">{title}</h1>
      <p className="mt-2 text-muted max-w-prose">Mission Administrators see mission summaries only. This page contains individual health detail and needs Astronaut or Medical Officer access.</p>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>("Dashboard");
  const [idx, setIdx] = useState(1);
  const [day, setDay] = useState(14);
  const [role, setRole] = useState<Role>("Astronaut");
  const [envId, setEnvId] = useState("transit");
  const [online, setOnline] = useState(true);
  const [queued, setQueued] = useState(0);
  const [syncNote, setSyncNote] = useState("");
  const [extra, setExtra] = useState<Record<string, DayReading[]>>({});
  const [symptoms, setSymptoms] = useState<Record<string, string[]>>({});
  const [done, setDone] = useState<Record<string, string[]>>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      setExtra(await load("astravyta:extra", {}));
      setSymptoms(await load("astravyta:symptoms", {}));
      setDone(await load("astravyta:done", {}));
      setQueued((await getQueue()).length);
      setReady(true);
    })();
  }, []);
  useEffect(() => { if (ready) void save("astravyta:extra", extra); }, [extra, ready]);
  useEffect(() => { if (ready) void save("astravyta:symptoms", symptoms); }, [symptoms, ready]);
  useEffect(() => { if (ready) void save("astravyta:done", done); }, [done, ready]);

  const crew = CREW[idx];
  const env = ENVS.find((e) => e.id === envId) ?? ENVS[0];
  const base = useMemo(() => generate(crew), [crew]);
  const rows = useMemo(() => [...base, ...(extra[crew.id] ?? [])], [base, extra, crew]);
  const d = Math.min(day, rows.length);
  const key = dayKey(crew.id, d);

  const alerts = useMemo(
    () => [...ruleAlerts(rows, d), ...anomalyFindings(rows, d), ...symptomAlerts(symptoms[key] ?? [], d)],
    [rows, d, symptoms, key],
  );
  const doneToday = done[key] ?? [];
  const due = d === rows.length ? TASKS.filter((t) => !doneToday.includes(t.id)) : [];
  const prog = useMemo(() => progress(done, crew.id, d), [done, crew, d]);

  // Offline: alerts are produced locally and saved to IndexedDB. Online: the queue is synced.
  useEffect(() => {
    if (online) {
      flush().then((r) => {
        getQueue().then((q) => setQueued(q.length));
        setSyncNote(r.sent ? `${r.sent} record${r.sent === 1 ? "" : "s"} synced.` : r.ok ? "" : "Server unreachable. Records stay saved locally.");
      });
      return;
    }
    (async () => {
      let n = 0;
      for (const x of alerts)
        n = await enqueue({ id: `${crew.id}-${x.id}`, astronaut: crew.name, day: d, severity: x.severity, message: x.title, createdAt: new Date().toISOString() });
      setQueued(n || (await getQueue()).length);
    })();
  }, [online, alerts, crew, d]);

  const submitCheckIn = (r: DayReading, syms: string[]) => {
    const next = rows.length + 1;
    const nk = dayKey(crew.id, next);
    setExtra((e) => ({ ...e, [crew.id]: [...(e[crew.id] ?? []), r] }));
    setSymptoms((s) => ({ ...s, [nk]: syms }));
    const ids = ["checkin", "glucose", "air"];
    if (r.ex >= 60) ids.push("exercise");
    setDone((x) => ({ ...x, [nk]: Array.from(new Set([...(x[nk] ?? []), ...ids])) }));
    setDay(next);
    setTab("Dashboard");
  };
  const toggleTask = (id: string) =>
    setDone((x) => {
      const cur = x[key] ?? [];
      return { ...x, [key]: cur.includes(id) ? cur.filter((i) => i !== id) : [...cur, id] };
    });

  const admin = role === "Mission Administrator";

  return (
    <div className="md:flex">
      <Sidebar tab={tab} setTab={setTab} online={online} setOnline={setOnline} queued={queued} syncNote={syncNote} />
      <main className="flex-1 min-w-0 p-4 md:p-8">
        <div className="mb-3 rounded-md border-l-4 border-warn bg-panel px-3 py-2 text-xs text-muted">
          Research prototype using simulated data. Not a clinically validated diagnostic system.
        </div>
        <div className="mb-8 flex flex-wrap items-end gap-4">
          <label className="text-xs text-muted">Astronaut
            <select className={`${field} block mt-1`} value={idx} onChange={(e) => setIdx(+e.target.value)}>
              {CREW.map((c, i) => <option key={c.id} value={i}>{c.name} ({c.scenario})</option>)}
            </select>
          </label>
          <label className="text-xs text-muted">Environment
            <select className={`${field} block mt-1`} value={envId} onChange={(e) => setEnvId(e.target.value)}>
              {ENVS.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </label>
          <label className="text-xs text-muted">Signed in as
            <select className={`${field} block mt-1`} value={role} onChange={(e) => setRole(e.target.value as Role)}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>
          <label className="text-xs text-muted flex-1 min-w-[220px]">Mission day {d} of {rows.length}
            <input type="range" min={BASE_DAYS + 1} max={rows.length} value={d} onChange={(e) => setDay(+e.target.value)} className="block w-full mt-3 accent-[#0E7490]" />
          </label>
        </div>

        {tab === "Dashboard" && <Dashboard crew={crew} rows={rows} day={d} role={role} env={env} alerts={alerts} due={due} onGo={setTab} />}
        {tab === "Body map" && (admin ? <Restricted title="Body map" /> : <BodyMap rows={rows} day={d} alerts={alerts} env={env} />)}
        {tab === "Check-in" && <CheckIn key={`${crew.id}-${rows.length}`} rows={rows} role={role} onSubmit={submitCheckIn} onGo={setTab} />}
        {tab === "Mission routine" && (admin ? <Restricted title="Mission routine" /> : <Routine crewName={crew.name} day={d} done={doneToday} onToggle={toggleTask} p={prog} />)}
        {tab === "Indicator guide" && <Guide />}
        {tab === "Risk coverage" && <Coverage />}
        {tab === "Reports" && <Reports crew={crew} rows={rows} day={d} role={role} alerts={alerts} />}
      </main>
    </div>
  );
}

import { useState } from "react";
import { GUIDE } from "../lib/guide";
import { KEYS, METRICS } from "../lib/metrics";
import type { MetricKey } from "../lib/types";

export default function Guide() {
  const [k, setK] = useState<MetricKey>("glu");
  const m = METRICS[k], g = GUIDE[k];
  return (
    <div>
      <h1 className="text-3xl font-bold">Indicator guide</h1>
      <p className="mt-1 text-muted max-w-prose">How to take each measurement, why it matters in space, and when to call the flight surgeon. Reference ranges are typical adult values for education. The mission flight surgeon sets the real limits.</p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[240px_minmax(0,1fr)]">
        <nav aria-label="Indicators" className="flex lg:flex-col gap-1 flex-wrap">
          {KEYS.map((x) => (
            <button key={x} onClick={() => setK(x)} aria-current={k === x ? "true" : undefined}
              className={`text-left rounded-md px-3 py-2 text-sm ${k === x ? "bg-ink text-white" : "bg-panel border border-line hover:bg-white"}`}>
              {METRICS[x].label}
            </button>
          ))}
        </nav>
        <article className="rounded-lg bg-panel border border-line p-5">
          <h2 className="text-2xl font-bold">{m.label} <span className="text-base font-normal text-muted">({m.unit})</span></h2>
          <p className="mt-1 text-sm text-muted">Measured with: {g.device}</p>
          <h3 className="mt-5 text-sm font-semibold">How to measure</h3>
          <ol className="mt-1 list-decimal pl-5 text-sm space-y-1">{g.how.map((x) => <li key={x}>{x}</li>)}</ol>
          <div className="mt-5 grid gap-5 md:grid-cols-2">
            <div><h3 className="text-sm font-semibold">What is normal</h3><p className="mt-1 text-sm">{g.range}</p></div>
            <div><h3 className="text-sm font-semibold">Why it matters</h3><p className="mt-1 text-sm">{g.why}</p></div>
            <div><h3 className="text-sm font-semibold">How spaceflight changes it</h3><p className="mt-1 text-sm">{g.hazard}</p></div>
            <div><h3 className="text-sm font-semibold">Contact the flight surgeon if</h3><p className="mt-1 text-sm">{g.call}</p></div>
          </div>
          <p className="mt-5 text-sm"><span className="font-semibold">If it is off:</span> {m.action}</p>
          <p className="mt-2 text-xs text-muted">NASA risk: {m.risk}</p>
        </article>
      </div>

      <section className="mt-8 rounded-lg bg-panel border border-line p-5">
        <h2 className="text-lg font-semibold">Reading the colors</h2>
        <ul className="mt-2 grid gap-3 sm:grid-cols-3 text-sm">
          <li><span className="font-semibold text-ok">Nominal</span><br />Inside your own baseline and the configured limits.</li>
          <li><span className="font-semibold text-warn">Watch</span><br />Drifting away from your baseline, or a symptom reported. Act on the next step and keep logging.</li>
          <li><span className="font-semibold text-crit">Needs review</span><br />Outside a limit, several indicators moving together, or an emergency symptom. Contact the flight surgeon.</li>
        </ul>
      </section>
    </div>
  );
}

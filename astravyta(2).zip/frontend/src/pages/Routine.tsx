import { TASKS, XP_PER_LEVEL, type progress } from "../lib/tasks";

interface Props { crewName: string; day: number; done: string[]; onToggle: (id: string) => void; p: ReturnType<typeof progress> }

export default function Routine({ crewName, day, done, onToggle, p }: Props) {
  const total = TASKS.length;
  return (
    <div className="max-w-4xl">
      <h1 className="text-3xl font-bold">Mission routine</h1>
      <p className="mt-1 text-muted">{crewName} · Day {day}. Small daily habits protect bones, heart and mind.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg bg-panel border border-line p-4">
          <p className="text-xs text-muted">Level</p>
          <p className="text-3xl font-bold">{p.level}</p>
          <div className="mt-2 h-2 rounded-full bg-line" role="progressbar" aria-valuenow={p.into} aria-valuemin={0} aria-valuemax={XP_PER_LEVEL}>
            <div className="h-2 rounded-full bg-signal" style={{ width: `${(p.into / XP_PER_LEVEL) * 100}%` }} />
          </div>
          <p className="mt-1 text-xs text-muted">{p.xp} XP total · {XP_PER_LEVEL - p.into} to next level</p>
        </div>
        <div className="rounded-lg bg-panel border border-line p-4">
          <p className="text-xs text-muted">Streak</p>
          <p className="text-3xl font-bold">{p.streak} <span className="text-base font-normal text-muted">day{p.streak === 1 ? "" : "s"}</span></p>
          <p className="mt-1 text-xs text-muted">Days in a row with every essential task done.</p>
        </div>
        <div className="rounded-lg bg-panel border border-line p-4">
          <p className="text-xs text-muted">Today</p>
          <p className="text-3xl font-bold">{done.length}<span className="text-base font-normal text-muted"> / {total}</span></p>
          <p className="mt-1 text-xs text-muted">Tasks completed.</p>
        </div>
      </div>

      <h2 className="mt-8 text-lg font-semibold">Today's tasks</h2>
      <ul className="mt-2 space-y-2">
        {TASKS.map((t) => {
          const d = done.includes(t.id);
          return (
            <li key={t.id}>
              <label className={`flex items-start gap-3 rounded-lg border p-3 cursor-pointer ${d ? "border-ok/40 bg-green-50" : "border-line bg-panel"}`}>
                <input type="checkbox" className="mt-1 h-4 w-4" checked={d} onChange={() => onToggle(t.id)} />
                <span className="flex-1">
                  <span className="block text-sm font-semibold">{t.label}{t.essential && <span className="ml-2 text-xs font-normal text-muted">essential</span>}</span>
                  <span className="block text-xs text-muted">{t.detail}</span>
                </span>
                <span className="text-xs font-semibold text-signal">+{t.xp} XP</span>
              </label>
            </li>
          );
        })}
      </ul>

      <h2 className="mt-8 text-lg font-semibold">Badges</h2>
      <ul className="mt-2 grid gap-3 sm:grid-cols-2">
        {p.badges.map((b) => (
          <li key={b.id} className={`rounded-lg border p-3 ${b.earned ? "border-signal bg-teal-50" : "border-line bg-panel opacity-70"}`}>
            <p className="text-sm font-semibold">{b.label} {b.earned && <span className="text-xs font-normal text-signal">Earned</span>}</p>
            <p className="text-xs text-muted">{b.detail}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

import { useState } from "react";
import BodyFigure, { type Status } from "../components/BodyFigure";
import { SYSTEMS, type BodySystem } from "../lib/body";
import type { Env } from "../lib/environments";
import { METRICS, fmt } from "../lib/metrics";
import type { Alert, DayReading } from "../lib/types";

const LABEL = { ok: "Nominal", warn: "Watch", crit: "Needs review" } as const;
const TONE = { ok: "text-ok", warn: "text-warn", crit: "text-crit" } as const;

function statusOf(s: BodySystem, alerts: Alert[]): Status {
  const keys = new Set<string>([...s.metrics, ...s.symptoms]);
  const hits = alerts.filter((a) => a.keys?.some((k) => keys.has(k)));
  return hits.some((a) => a.severity === "critical") ? "crit" : hits.length ? "warn" : "ok";
}

export default function BodyMap({ rows, day, alerts, env }: { rows: DayReading[]; day: number; alerts: Alert[]; env: Env }) {
  const [sel, setSel] = useState("heart");
  const status = Object.fromEntries(SYSTEMS.map((s) => [s.id, statusOf(s, alerts)])) as Record<string, Status>;
  const s = SYSTEMS.find((x) => x.id === sel) ?? SYSTEMS[0];
  const st = status[s.id];

  return (
    <div>
      <h1 className="text-3xl font-bold">Body map</h1>
      <p className="mt-1 text-muted max-w-prose">Select a body system to see what it does, how spaceflight affects it, and what to do next. Colors show today's status.</p>
      <div className="mt-6 grid gap-6 lg:grid-cols-[300px_minmax(0,1fr)]">
        <div className="rounded-lg bg-panel border border-line p-4">
          <BodyFigure status={status} selected={sel} onSelect={setSel} />
          <div className="mt-3 flex flex-wrap gap-2">
            {SYSTEMS.map((x) => (
              <button key={x.id} onClick={() => setSel(x.id)} aria-pressed={sel === x.id}
                className={`rounded-full border px-3 py-1 text-xs ${sel === x.id ? "border-ink bg-ink text-white" : "border-line"}`}>
                <span className={`mr-1 inline-block h-2 w-2 rounded-full ${status[x.id] === "crit" ? "bg-crit" : status[x.id] === "warn" ? "bg-warn" : "bg-ok"}`} />
                {x.name}
              </button>
            ))}
          </div>
        </div>

        <article className="rounded-lg bg-panel border border-line p-5">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="text-2xl font-bold">{s.name}</h2>
            <span className={`text-sm font-semibold ${TONE[st]}`}>{LABEL[st]}</span>
          </div>
          <p className="mt-1">{s.does}</p>
          <h3 className="mt-5 text-sm font-semibold">How spaceflight affects it</h3>
          <p className="mt-1 text-sm text-muted max-w-prose">{s.spaceEffect}</p>
          <div className="mt-2 flex flex-wrap gap-2">{s.hazards.map((h) => <span key={h} className="rounded-full border border-line px-2 py-0.5 text-xs">{h}</span>)}</div>

          <h3 className="mt-5 text-sm font-semibold">Linked indicators (day {day})</h3>
          {s.metrics.length === 0 ? <p className="mt-1 text-sm text-muted">No measured indicator. Report symptoms in the daily check-in.</p> : (
            <ul className="mt-2 grid gap-2 sm:grid-cols-3">
              {s.metrics.map((k) => (
                <li key={k} className="rounded-md border border-line p-2">
                  <span className="block text-xs text-muted">{METRICS[k].label}</span>
                  <span className="text-lg font-semibold">{fmt(rows[day - 1][k], k)} <span className="text-xs font-normal text-muted">{METRICS[k].unit}</span></span>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-5 grid gap-5 md:grid-cols-2">
            <div>
              <h3 className="text-sm font-semibold">What you can do</h3>
              <ul className="mt-1 list-disc pl-5 text-sm space-y-1">{s.selfCare.map((x) => <li key={x}>{x}</li>)}</ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold">Contact the flight surgeon if</h3>
              <ul className="mt-1 list-disc pl-5 text-sm space-y-1">{s.callGround.map((x) => <li key={x}>{x}</li>)}</ul>
            </div>
          </div>
          <p className="mt-4 rounded-md bg-paper p-3 text-sm">
            {env.autonomous ? `Ground replies can take a long time here (${env.delay}). Send your data first, follow the steps above, and do not wait for a reply before acting on an emergency.` : `Ground contact is near real time here (${env.delay}).`}
          </p>
          <p className="mt-3 text-xs text-muted">NASA risks: {s.risks.join(" · ")}. Decision support only, not a diagnosis.</p>
        </article>
      </div>
    </div>
  );
}

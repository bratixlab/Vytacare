import { useState } from "react";
import type { Tab } from "../components/Sidebar";
import { METRICS } from "../lib/metrics";
import { SYMPTOMS } from "../lib/symptoms";
import type { DayReading, MetricKey, Role } from "../lib/types";

interface F { k: MetricKey; hint: string; min: number; max: number; step: number }
const GROUPS: { title: string; fields: F[] }[] = [
  { title: "Vitals", fields: [
    { k: "hr", hint: "Resting, after 5 minutes of rest", min: 30, max: 220, step: 1 },
    { k: "sys", hint: "Upper-arm cuff, second reading", min: 60, max: 220, step: 1 },
    { k: "temp", hint: "Forehead or oral thermometer", min: 34, max: 41, step: 0.1 },
    { k: "spo2", hint: "Fingertip oximeter, steady reading", min: 70, max: 100, step: 0.1 },
    { k: "glu", hint: "Fingerstick meter", min: 20, max: 600, step: 1 } ] },
  { title: "Body and mind", fields: [
    { k: "sleep", hint: "Hours slept in your last sleep period", min: 0, max: 16, step: 0.1 },
    { k: "mood", hint: "1 very low to 10 very good", min: 1, max: 10, step: 0.5 },
    { k: "stress", hint: "1 calm to 10 overwhelmed", min: 1, max: 10, step: 0.5 },
    { k: "ex", hint: "Total minutes of planned exercise", min: 0, max: 360, step: 5 } ] },
  { title: "Cabin environment", fields: [
    { k: "co2", hint: "Cabin monitor, in ppm", min: 400, max: 20000, step: 10 },
    { k: "rad", hint: "Personal dosimeter, daily dose", min: 0, max: 5000, step: 5 } ] },
];

interface Props { rows: DayReading[]; role: Role; onSubmit: (r: DayReading, symptoms: string[]) => void; onGo: (t: Tab) => void }

export default function CheckIn({ rows, role, onSubmit, onGo }: Props) {
  const last = rows[rows.length - 1];
  const [v, setV] = useState<Record<string, string>>(() =>
    Object.fromEntries(GROUPS.flatMap((g) => g.fields).map((f) => [f.k, String(Number(last[f.k].toFixed(f.step < 1 ? 1 : 0)))])));
  const [syms, setSyms] = useState<string[]>([]);
  const [errs, setErrs] = useState<string[]>([]);
  const next = rows.length + 1;

  if (role !== "Astronaut")
    return <div><h1 className="text-3xl font-bold">Daily check-in</h1><p className="mt-2 text-muted max-w-prose">Only the astronaut logs their own readings. Switch "Signed in as" to Astronaut to record a check-in.</p></div>;
  if (rows.length >= 30)
    return <div><h1 className="text-3xl font-bold">Daily check-in</h1><p className="mt-2 text-muted">This prototype stores up to 30 mission days.</p></div>;

  const submit = () => {
    const e: string[] = [];
    const r = {} as DayReading;
    for (const f of GROUPS.flatMap((g) => g.fields)) {
      const n = Number(v[f.k]);
      if (v[f.k].trim() === "" || Number.isNaN(n) || n < f.min || n > f.max) e.push(`${METRICS[f.k].label}: enter a value from ${f.min} to ${f.max} ${METRICS[f.k].unit}.`);
      r[f.k] = n;
    }
    setErrs(e);
    if (!e.length) onSubmit(r, syms);
  };
  const toggle = (id: string) => setSyms((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  return (
    <div className="max-w-4xl">
      <h1 className="text-3xl font-bold">Daily check-in · Day {next}</h1>
      <p className="mt-1 text-muted max-w-prose">Enter today's readings. Not sure how to take one? <button className="underline text-signal" onClick={() => onGo("Indicator guide")}>Open the indicator guide</button>.</p>

      {GROUPS.map((g) => (
        <fieldset key={g.title} className="mt-6 rounded-lg bg-panel border border-line p-4">
          <legend className="px-1 text-sm font-semibold">{g.title}</legend>
          <div className="grid gap-4 sm:grid-cols-2">
            {g.fields.map((f) => (
              <div key={f.k}>
                <label htmlFor={f.k} className="text-sm font-medium">{METRICS[f.k].label} <span className="text-muted font-normal">({METRICS[f.k].unit})</span></label>
                <input id={f.k} type="number" inputMode="decimal" step={f.step} min={f.min} max={f.max} value={v[f.k]}
                  onChange={(e) => setV({ ...v, [f.k]: e.target.value })}
                  className="mt-1 w-full rounded-md border border-line bg-paper px-3 py-2 text-sm" />
                <p className="mt-1 text-xs text-muted">{f.hint}</p>
              </div>
            ))}
          </div>
        </fieldset>
      ))}

      <fieldset className="mt-6 rounded-lg bg-panel border border-line p-4">
        <legend className="px-1 text-sm font-semibold">Symptoms today</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {SYMPTOMS.map((s) => (
            <label key={s.id} className={`flex items-center gap-2 rounded-md border px-3 py-2 text-sm cursor-pointer ${syms.includes(s.id) ? (s.red ? "border-crit bg-red-50" : "border-warn bg-amber-50") : "border-line"}`}>
              <input type="checkbox" checked={syms.includes(s.id)} onChange={() => toggle(s.id)} />
              {s.label}
            </label>
          ))}
        </div>
      </fieldset>

      {errs.length > 0 && (
        <ul role="alert" className="mt-4 rounded-md border border-crit/40 bg-red-50 p-3 text-sm list-disc pl-6">{errs.map((x) => <li key={x}>{x}</li>)}</ul>
      )}
      <button onClick={submit} className="mt-6 rounded-md bg-signal px-5 py-2.5 text-sm font-semibold text-white">Save check-in</button>
      <p className="mt-2 text-xs text-muted">Saved on this device first, then synced when the ground link is online.</p>
    </div>
  );
}

import AlertCard from "../components/AlertCard";
import EnvStrip from "../components/EnvStrip";
import MetricPanel from "../components/MetricPanel";
import type { Tab } from "../components/Sidebar";
import type { Env } from "../lib/environments";
import { healthScore, type Task } from "../lib/tasks";
import type { Alert, Astronaut, DayReading, MetricKey, Role } from "../lib/types";

const PANELS: MetricKey[] = ["hr", "sys", "spo2", "glu", "sleep", "mood", "stress", "co2"];

interface Props {
  crew: Astronaut; rows: DayReading[]; day: number; role: Role; env: Env; alerts: Alert[]; due: Task[]; onGo: (t: Tab) => void;
}

function Ring({ score }: { score: number }) {
  const r = 34, c = 2 * Math.PI * r;
  const col = score >= 80 ? "#2F855A" : score >= 55 ? "#B7791F" : "#C53030";
  return (
    <div className="relative h-24 w-24" role="img" aria-label={`Health score ${score} out of 100`}>
      <svg viewBox="0 0 80 80" className="h-24 w-24 -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="#D5DDE5" strokeWidth="7" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={col} strokeWidth="7" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - score / 100)} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold leading-none">{score}</span>
        <span className="text-[10px] text-muted">Health score</span>
      </div>
    </div>
  );
}

export default function Dashboard({ crew, rows, day, role, env, alerts, due, onGo }: Props) {
  const critical = alerts.some((x) => x.severity === "critical");
  const state = critical ? "Needs review" : alerts.length ? "Watch" : "Nominal";
  const tone = critical ? "text-crit" : alerts.length ? "text-warn" : "text-ok";
  const restricted = role === "Mission Administrator";
  const nA = alerts.filter((x) => x.engine === "A").length;
  const nB = alerts.filter((x) => x.engine === "B").length;
  const nS = alerts.filter((x) => x.engine === "S").length;
  const summary = alerts.length === 0
    ? "Every indicator is inside this astronaut's personal baseline and the configured limits."
    : `${nA} rule or limit alert${nA === 1 ? "" : "s"}, ${nB} trend finding${nB === 1 ? "" : "s"} and ${nS} reported symptom${nS === 1 ? "" : "s"} on day ${day}.`;
  const surgeon = alerts.some((x) => x.severity === "critical") && env.autonomous;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-6">
        <div>
          <p className="text-sm text-muted">{crew.name} · Mission day {day} of {rows.length}</p>
          <h1 className={`text-4xl md:text-5xl font-bold ${tone}`}>{state}</h1>
          <p className="mt-1 text-base max-w-prose">{summary}</p>
        </div>
        {!restricted && <Ring score={healthScore(alerts)} />}
      </div>

      {surgeon && (
        <p className="rounded-md border border-crit/40 bg-red-50 px-3 py-2 text-sm">
          Ground replies can take a long time here ({env.delay}). Send your data to the flight surgeon now, and follow the next steps below while you wait.
        </p>
      )}

      {!restricted && due.length > 0 && (
        <section className="rounded-lg bg-panel border border-line p-4" aria-label="Due now">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold">Due now</h2>
            <button onClick={() => onGo("Check-in")} className="rounded-md bg-signal px-3 py-1.5 text-sm font-medium text-white">Start check-in</button>
          </div>
          <ul className="mt-2 flex flex-wrap gap-2">
            {due.slice(0, 4).map((t) => <li key={t.id} className="rounded-full border border-line px-3 py-1 text-xs">{t.label}</li>)}
          </ul>
        </section>
      )}

      <EnvStrip env={env} />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">
        {restricted ? (
          <div className="rounded-lg bg-panel border border-line p-6 text-sm text-muted">
            Mission Administrators see mission summaries only. Charts, readings and medical explanations require Astronaut or Medical Officer access.
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {PANELS.map((k) => <MetricPanel key={k} rows={rows} k={k} day={day} />)}
          </div>
        )}
        <div>
          <h2 className="text-lg font-semibold mb-3">Review queue</h2>
          <div className="space-y-3">
            {alerts.length === 0 && <p className="text-sm text-muted">No alerts. Move the day control or choose another astronaut to see detection.</p>}
            {alerts.map((x) => <AlertCard key={x.id} a={x} restricted={restricted} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

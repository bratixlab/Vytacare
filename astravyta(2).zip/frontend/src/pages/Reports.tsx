import { useState } from "react";
import { KEYS, METRICS, fmt } from "../lib/metrics";
import type { Alert, Astronaut, DayReading, Role } from "../lib/types";

interface Props { crew: Astronaut; rows: DayReading[]; day: number; role: Role; alerts: Alert[] }

export default function Reports({ crew, rows, day, role, alerts }: Props) {
  const [comments, setComments] = useState<Record<string, string[]>>({});
  const [draft, setDraft] = useState("");
  const [copied, setCopied] = useState(false);

  if (role === "Mission Administrator")
    return (
      <div>
        <h1 className="text-3xl font-bold">Mission summary</h1>
        <p className="mt-2 text-muted max-w-prose">{crew.name}: {alerts.length} active alert{alerts.length === 1 ? "" : "s"}. Individual health reports and clinical comments require explicit permission.</p>
      </div>
    );

  const lines = KEYS.filter((k) => METRICS[k].group !== "Environment").map((k) => `${METRICS[k].label}: ${fmt(rows[day - 1][k], k)} ${METRICS[k].unit}`);
  const text = [`ASTRAVYTA daily health summary`, `${crew.name} · Mission day ${day}`, ...lines,
    `Active alerts: ${alerts.length ? alerts.map((a) => a.title).join("; ") : "none"}`,
    `Simulated data. Decision support only, not a diagnosis.`].join("\n");
  const key = `${crew.id}-${day}`;

  const copy = async () => { try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { /* clipboard unavailable */ } };
  const add = () => { if (!draft.trim()) return; setComments({ ...comments, [key]: [...(comments[key] ?? []), draft.trim()] }); setDraft(""); };

  return (
    <div className="max-w-3xl">
      <h1 className="text-3xl font-bold">Daily health summary</h1>
      <pre className="mt-4 whitespace-pre-wrap rounded-lg bg-panel border border-line p-4 text-sm font-sans">{text}</pre>
      <button onClick={copy} className="mt-3 rounded-md bg-ink text-white px-4 py-2 text-sm font-medium hover:bg-rail">{copied ? "Copied" : "Copy report"}</button>

      <h2 className="mt-8 text-lg font-semibold">Medical Officer comments</h2>
      <div className="mt-2 space-y-2">
        {(comments[key] ?? []).length === 0 && <p className="text-sm text-muted">No comments for day {day}.</p>}
        {(comments[key] ?? []).map((c, i) => <p key={i} className="rounded-md bg-panel border border-line p-3 text-sm">{c}</p>)}
      </div>
      {role === "Medical Officer" ? (
        <div className="mt-3">
          <label htmlFor="c" className="text-sm font-medium">Document an assessment or intervention</label>
          <textarea id="c" value={draft} onChange={(e) => setDraft(e.target.value)} rows={3} className="mt-1 w-full rounded-md border border-line bg-panel p-2 text-sm" />
          <button onClick={add} className="mt-2 rounded-md bg-signal text-white px-4 py-2 text-sm font-medium">Add comment</button>
        </div>
      ) : <p className="mt-3 text-sm text-muted">Only a Medical Officer can add comments.</p>}
    </div>
  );
}

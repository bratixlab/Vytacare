import { RISKS } from "../lib/metrics";

const STYLE = { Full: "bg-teal-50 text-signal border-signal/30", Partial: "bg-amber-50 text-warn border-warn/30", Record: "bg-slate-100 text-muted border-line" };
const NOTE = { Full: "Automated detection", Partial: "Tracked with trends", Record: "Structured log or assessment only" };

export default function Coverage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">NASA Human Research Program risks</h1>
      <p className="mt-1 text-muted max-w-prose">All 17 risks are covered by a feature. We do not claim to diagnose conditions such as cancer or bone loss from wearable readings.</p>
      <div className="mt-6 overflow-x-auto rounded-lg bg-panel border border-line">
        <table className="w-full text-sm">
          <thead className="text-left text-muted"><tr><th className="p-3">Risk</th><th className="p-3">Coverage</th><th className="p-3">Feature</th></tr></thead>
          <tbody>
            {RISKS.map(([r, level, f]) => (
              <tr key={r} className="border-t border-line">
                <td className="p-3 font-medium">{r}</td>
                <td className="p-3"><span title={NOTE[level]} className={`rounded-full border px-2 py-0.5 text-xs ${STYLE[level]}`}>{level === "Record" ? "Record only" : level}</span></td>
                <td className="p-3 text-muted">{f}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

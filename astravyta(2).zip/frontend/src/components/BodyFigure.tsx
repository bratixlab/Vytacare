import type { KeyboardEvent, ReactNode } from "react";

export type Status = "ok" | "warn" | "crit";
const FILL: Record<Status, string> = { ok: "#2F855A", warn: "#B7791F", crit: "#C53030" };

interface Props { status: Record<string, Status>; selected: string; onSelect: (id: string) => void }

export default function BodyFigure({ status, selected, onSelect }: Props) {
  const zone = (id: string, label: string, children: ReactNode, light = false) => {
    const c = FILL[status[id] ?? "ok"];
    const sel = selected === id;
    return (
      <g role="button" tabIndex={0} aria-label={label} aria-pressed={sel} style={{ cursor: "pointer" }}
        onClick={() => onSelect(id)}
        onKeyDown={(e: KeyboardEvent) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(id); } }}
        fill={light ? "#E3EAF0" : c} fillOpacity={light ? 1 : sel ? 0.6 : 0.3}
        stroke={sel ? "#102A43" : light && status[id] !== "warn" && status[id] !== "crit" ? "#9DB0C0" : c}
        strokeWidth={sel ? 3 : 1.5}>
        <title>{label}</title>
        {children}
      </g>
    );
  };

  return (
    <svg viewBox="0 0 220 430" className="mx-auto w-full max-w-[280px]" role="group" aria-label="Clickable human body">
      {zone("immune", "Immune system and skin", <>
        <circle cx="110" cy="50" r="30" />
        <rect x="100" y="78" width="20" height="16" />
        <rect x="68" y="92" width="84" height="140" rx="28" />
        <rect x="40" y="98" width="22" height="140" rx="11" />
        <rect x="158" y="98" width="22" height="140" rx="11" />
        <rect x="74" y="226" width="30" height="190" rx="14" />
        <rect x="116" y="226" width="30" height="190" rx="14" />
      </>, true)}
      {zone("bones", "Bones and muscles", <>
        <rect x="46" y="110" width="10" height="116" rx="5" />
        <rect x="164" y="110" width="10" height="116" rx="5" />
        <rect x="83" y="250" width="12" height="150" rx="6" />
        <rect x="125" y="250" width="12" height="150" rx="6" />
      </>)}
      {zone("gut", "Metabolism and nutrition", <ellipse cx="110" cy="198" rx="30" ry="22" />)}
      {zone("lungs", "Lungs and oxygen", <>
        <ellipse cx="88" cy="128" rx="18" ry="30" />
        <ellipse cx="132" cy="128" rx="18" ry="30" />
      </>)}
      {zone("heart", "Heart and circulation", <path d="M110 166 C 90 148, 92 130, 104 130 C 108 130, 110 133, 110 136 C 110 133, 112 130, 116 130 C 128 130, 130 148, 110 166 Z" />)}
      {zone("brain", "Brain and mind", <ellipse cx="110" cy="38" rx="20" ry="14" />)}
      {zone("eyes", "Eyes", <>
        <circle cx="100" cy="58" r="5" />
        <circle cx="120" cy="58" r="5" />
      </>)}
    </svg>
  );
}

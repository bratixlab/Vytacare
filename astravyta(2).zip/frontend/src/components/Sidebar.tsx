export type Tab = "Dashboard" | "Body map" | "Check-in" | "Mission routine" | "Indicator guide" | "Risk coverage" | "Reports";
const GROUPS: { title: string; tabs: Tab[] }[] = [
  { title: "Monitor", tabs: ["Dashboard", "Body map", "Check-in"] },
  { title: "Act", tabs: ["Mission routine", "Indicator guide"] },
  { title: "Review", tabs: ["Risk coverage", "Reports"] },
];

interface Props {
  tab: Tab;
  setTab: (t: Tab) => void;
  online: boolean;
  setOnline: (v: boolean) => void;
  queued: number;
  syncNote: string;
}

export default function Sidebar({ tab, setTab, online, setOnline, queued, syncNote }: Props) {
  return (
    <aside className="bg-rail text-slate-200 md:w-64 md:min-h-screen shrink-0 flex md:flex-col gap-4 md:gap-6 p-4 md:p-6 md:sticky md:top-0 md:h-screen md:overflow-y-auto flex-wrap">
      <div className="w-full md:w-auto">
        <div className="text-xl font-bold tracking-wide text-white">ASTRAVYTA</div>
        <div className="text-xs text-slate-400">BRATIXLAB · NASA Space Apps 2026</div>
      </div>
      <nav className="flex md:flex-col gap-4 flex-1 flex-wrap" aria-label="Main">
        {GROUPS.map((g) => (
          <div key={g.title}>
            <div className="px-3 pb-1 text-xs text-slate-400">{g.title}</div>
            <div className="flex md:flex-col gap-1 flex-wrap">
              {g.tabs.map((t) => (
                <button key={t} onClick={() => setTab(t)} aria-current={tab === t ? "page" : undefined}
                  className={`text-left rounded-md px-3 py-2 text-sm font-medium transition-colors ${tab === t ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5"}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>
      <div className="text-sm w-full md:w-auto">
        <button onClick={() => setOnline(!online)} aria-pressed={online}
          className="flex items-center gap-2 rounded-md border border-white/15 px-3 py-2 w-full hover:bg-white/5">
          <span className={`h-2.5 w-2.5 rounded-full ${online ? "bg-emerald-400" : "bg-amber-400"}`} />
          {online ? "Ground link online" : "Ground link offline"}
        </button>
        <p className="mt-2 text-xs text-slate-400 min-h-[2.5rem]">
          {online ? syncNote || "Records are synced." : `${queued} record${queued === 1 ? "" : "s"} saved locally, waiting to sync.`}
        </p>
      </div>
    </aside>
  );
}

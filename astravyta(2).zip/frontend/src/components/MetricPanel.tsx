import { Area, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { baseline } from "../lib/engine";
import { METRICS, fmt } from "../lib/metrics";
import type { DayReading, MetricKey } from "../lib/types";

export default function MetricPanel({ rows, k, day }: { rows: DayReading[]; k: MetricKey; day: number }) {
  const m = METRICS[k];
  const { mean, sd } = baseline(rows, k);
  const cur = rows[day - 1][k];
  const z = (cur - mean) / sd;
  const bad = m.lowIsBad ? -z : z;
  const tone = bad >= 3.5 ? "text-crit" : bad >= 2 ? "text-warn" : "text-ink";
  const data = rows.map((r, i) => ({ day: i + 1, value: i < day ? r[k] : null, lo: mean - 2 * sd, band: 4 * sd }));

  return (
    <section className="rounded-lg bg-panel border border-line p-4">
      <header className="flex items-baseline justify-between gap-2">
        <h3 className="text-sm font-semibold">{m.label}</h3>
        <span className="text-xs text-muted">{m.group}</span>
      </header>
      <p className={`mt-1 text-3xl font-semibold ${tone}`}>
        {fmt(cur, k)} <span className="text-sm font-normal text-muted">{m.unit}</span>
      </p>
      <p className="text-xs text-muted">Baseline {fmt(mean, k)} ± {fmt(sd, k)} · {z >= 0 ? "+" : ""}{z.toFixed(1)} SD</p>
      <div className="h-32 mt-2" role="img" aria-label={`${m.label} trend with personal baseline corridor`}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
            <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#5B7083" }} tickLine={false} axisLine={{ stroke: "#D5DDE5" }} />
            <YAxis tick={{ fontSize: 10, fill: "#5B7083" }} tickLine={false} axisLine={false} domain={["auto", "auto"]} />
            <Tooltip formatter={(v) => `${Number(v).toFixed(m.digits + 1)} ${m.unit}`} labelFormatter={(d) => `Day ${d}`} />
            <Area dataKey="lo" stackId="c" stroke="none" fill="transparent" isAnimationActive={false} />
            <Area dataKey="band" stackId="c" stroke="none" fill="#0E7490" fillOpacity={0.12} isAnimationActive={false} />
            <ReferenceLine x={day} stroke="#5B7083" strokeDasharray="3 3" />
            <Line dataKey="value" stroke="#102A43" strokeWidth={2} dot={false} isAnimationActive={false} connectNulls />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <p className="text-xs text-muted">Shaded corridor: this astronaut's normal range (days 1 to 7, ±2 SD).</p>
    </section>
  );
}

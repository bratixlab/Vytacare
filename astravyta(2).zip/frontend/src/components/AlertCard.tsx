import type { Alert } from "../lib/types";

const SOURCE = { A: "Engine A · rules and limits", B: "Engine B · trend model", S: "Symptom check" } as const;

export default function AlertCard({ a, restricted }: { a: Alert; restricted: boolean }) {
  const crit = a.severity === "critical";
  return (
    <article className={`rounded-md bg-panel border border-line border-l-4 ${crit ? "border-l-crit" : "border-l-warn"} p-3`}>
      <div className="flex items-center gap-2 text-xs text-muted">
        <span className={`font-semibold ${crit ? "text-crit" : "text-warn"}`}>{crit ? "Needs review" : "Watch"}</span>
        <span>{SOURCE[a.engine]}</span>
      </div>
      {restricted ? (
        <p className="mt-1 text-sm font-medium">Alert active. Medical details are restricted for your role.</p>
      ) : (
        <>
          <h4 className="mt-1 text-sm font-semibold">{a.title}</h4>
          <p className="mt-1 text-sm text-muted">{a.why}</p>
          {a.points && (
            <p className="mt-1 text-xs text-muted">
              Last {a.points.length} days: {a.points.map((p) => p.toFixed(1)).join(", ")} · Pattern confidence {Math.round((a.confidence ?? 0) * 100)}% (not the chance of a diagnosis)
            </p>
          )}
          <p className="mt-2 text-sm"><span className="font-semibold">Next step:</span> {a.action}</p>
          <p className="mt-1 text-xs text-muted">NASA risk: {a.risk}</p>
        </>
      )}
    </article>
  );
}

import { HAZARDS, type Env } from "../lib/environments";

export default function EnvStrip({ env }: { env: Env }) {
  return (
    <section className="rounded-lg bg-panel border border-line p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold">{env.name}</h2>
        <span className="text-xs text-muted">Ground message delay: {env.delay}</span>
      </div>
      <p className="mt-1 text-sm text-muted max-w-prose">{env.blurb}</p>
      <ul className="mt-3 grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-5">
        {HAZARDS.map(([k, label]) => (
          <li key={k} className="text-xs">
            <span className="block text-muted">{label}</span>
            <span className="mt-1 flex gap-1" role="img" aria-label={`${env.hazards[k]} out of 3`}>
              {[1, 2, 3].map((n) => <span key={n} className={`h-1.5 flex-1 rounded-full ${n <= env.hazards[k] ? "bg-signal" : "bg-line"}`} />)}
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-sm"><span className="font-semibold">Watch most:</span> {env.focus}</p>
    </section>
  );
}

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ['"Schibsted Grotesk"', "system-ui", "sans-serif"] },
      colors: {
        paper: "#EDF0F3",
        panel: "#FFFFFF",
        ink: "#102A43",
        rail: "#0C2236",
        muted: "#5B7083",
        line: "#D5DDE5",
        signal: "#0E7490",
        ok: "#2F855A",
        warn: "#B7791F",
        crit: "#C53030",
      },
    },
  },
  plugins: [],
};

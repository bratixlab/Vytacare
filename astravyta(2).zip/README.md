# ASTRAVYTA

Astronaut health self-assessment and decision-support system. Built by **BRATIXLAB** for NASA Space Apps Challenge 2026 ("Create Health Monitoring Software for Astronauts on Space Missions").

> Research prototype using simulated data. It is not a clinically validated diagnostic system. Reference ranges and limits are examples; a mission flight surgeon sets the real ones.

## What it does (mapped to the challenge brief)
| Brief asks for | ASTRAVYTA |
|---|---|
| Visual tool for self-assessment | Dashboard with a status word, health score, review queue |
| Clickable human body | **Body map**: heart, lungs, brain, eyes, gut, bones/muscles, immune/skin with function, spaceflight effect, self-care and escalation |
| Data from user input | **Check-in**: vitals, blood glucose, sleep, mood, stress, exercise, cabin CO2, radiation, and a symptom checklist |
| Indicators (BP, heart rate, glucose, temperature, sleep, mood) | All covered, with personal baselines and configured limits |
| Color coding, dynamic charts | Green/amber/red status, charts with each astronaut's baseline corridor |
| Simple instructions and explanations | **Indicator guide**: how to measure, what is normal, why it matters in space, when to call the flight surgeon |
| Prompts for routine measurements, gamification | **Mission routine**: daily tasks, XP, levels, streaks, badges, "Due now" prompts |
| Different environments | Space station, deep-space transit, lunar base, Mars surface: hazards, message delay, autonomy guidance |
| Guidance on treatment and improvement | Self-care steps and explicit "contact the flight surgeon if" rules per system and indicator |

Extra: **Engine A** (limits + personal-baseline rules) and **Engine B** (trend model) give explainable alerts; offline-first storage (IndexedDB) with sync; roles (Astronaut, Medical Officer, Mission Administrator); all 17 NASA HRP risks mapped to coverage levels.

## Structure
```
astravyta/
  frontend/   React + TypeScript + Tailwind + Recharts (runs fully offline with simulated data)
  backend/    FastAPI API, Python risk engine, simulator, sync endpoint
  db/         PostgreSQL schema
  docs/       SRS summary
  docker-compose.yml
```

## Run the frontend
```bash
cd frontend
npm install
npm run dev        # http://localhost:5173
```

## Run the backend (optional for the demo)
```bash
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1        # Windows PowerShell
# source .venv/bin/activate       # Mac / Linux
pip install -r requirements.txt
uvicorn app.main:app --reload     # http://localhost:8000/docs
```
Windows tip: if `python` opens the Microsoft Store, install Python from python.org (tick "Add to PATH"), open a new terminal, or use `py` instead of `python`.

## Run PostgreSQL + API with Docker
```bash
docker compose up --build
```

## Demo script (3 minutes)
1. **Dashboard**, Okafor: nominal. Point out the environment strip and the "Due now" prompts.
2. Switch to **Li Wei**, Day 14: isolation drift. Show the review queue: rules, limits and trend findings with reasons and next steps.
3. Open **Body map**: click the brain, then the heart. Show how spaceflight affects each, what to do, when to call the surgeon.
4. Switch to **Ortega**, Day 14: HR up, SpO2 down, CO2 high. Show the combined hypoxia alert.
5. Choose **Mars surface** as the environment: the autonomy banner appears (4 to 24 minute delay).
6. As **Astronaut** with Okafor, open **Check-in**: enter glucose 55 and tick "Chest pain". Save. Show the immediate critical alerts.
7. Open **Mission routine**: XP, streak, badges. Open **Indicator guide** for "how to measure".
8. Turn the ground link **offline**, move the day slider: alerts queue locally. Turn it online: they sync (needs the backend running).
9. Switch role to **Mission Administrator**: medical detail is restricted.

## Status
Done: simulator, both engines with configured limits, body map, check-in with symptoms, indicator guide, routine and gamification, environments, offline queue, sync endpoint, PostgreSQL schema.
Next: authentication, PostgreSQL persistence in the API, a trained anomaly model, PDF export, camera or wearable input.

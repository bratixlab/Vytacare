-- ASTRAVYTA PostgreSQL schema (prototype)
CREATE TABLE missions (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  started_on DATE
);
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('astronaut','medical_officer','mission_administrator'))
);
CREATE TABLE astronauts (
  id TEXT PRIMARY KEY,
  user_id INT REFERENCES users(id),
  mission_id INT REFERENCES missions(id),
  full_name TEXT NOT NULL,
  callsign TEXT
);
CREATE TABLE baselines (
  astronaut_id TEXT REFERENCES astronauts(id),
  metric TEXT NOT NULL,
  mean DOUBLE PRECISION NOT NULL,
  sd DOUBLE PRECISION NOT NULL,
  approved_by INT REFERENCES users(id),
  PRIMARY KEY (astronaut_id, metric)
);
CREATE TABLE readings (
  id BIGSERIAL PRIMARY KEY,
  client_id TEXT UNIQUE,               -- generated offline; makes sync idempotent
  astronaut_id TEXT REFERENCES astronauts(id),
  mission_day INT NOT NULL,
  metric TEXT NOT NULL,
  value DOUBLE PRECISION NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON readings (astronaut_id, metric, mission_day);
CREATE TABLE alerts (
  id TEXT PRIMARY KEY,
  astronaut_id TEXT REFERENCES astronauts(id),
  engine CHAR(1) NOT NULL CHECK (engine IN ('A','B')),
  severity TEXT NOT NULL,
  mission_day INT NOT NULL,
  message TEXT NOT NULL,
  explanation TEXT,
  recommended_action TEXT,
  raised_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE medical_comments (
  id BIGSERIAL PRIMARY KEY,
  alert_id TEXT REFERENCES alerts(id),
  astronaut_id TEXT REFERENCES astronauts(id),
  author_id INT REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  actor TEXT,
  action TEXT NOT NULL,
  detail JSONB,
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

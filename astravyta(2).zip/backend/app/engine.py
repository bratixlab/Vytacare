"""Hybrid risk engine. Engine A: baseline rules. Engine B: multi-day trend anomaly detection."""
from statistics import mean, pstdev
from .simulator import SD

BASE_DAYS = 7
LOW_BAD = {"spo2", "sleep", "mood", "ex"}
LABEL = {"hr": "Heart rate", "sys": "Systolic BP", "temp": "Body temp", "spo2": "SpO2", "glu": "Blood glucose", "sleep": "Sleep",
         "mood": "Mood", "stress": "Stress", "ex": "Exercise", "co2": "Cabin CO2", "rad": "Radiation"}
RISK = {"hr": "Cardiovascular adaptations", "sys": "Cardiovascular adaptations", "temp": "Altered immune responses",
        "spo2": "Hypoxia", "glu": "Inadequate food and nutrition", "sleep": "Inadequate sleep", "mood": "Behavioral changes", "stress": "Behavioral changes",
        "ex": "Bone and muscle loss", "co2": "Hostile closed environment", "rad": "Radiation-induced cancers"}

# Example configured limits (lo, hi). The mission flight surgeon sets the real ones.
LIMITS = {"hr": (45, 100), "sys": (90, 140), "temp": (None, 37.8), "spo2": (92, None),
          "glu": (70, 140), "sleep": (5, None), "co2": (None, 5000)}


def baseline(rows, k):
    v = [r[k] for r in rows[:BASE_DAYS]]
    return mean(v), max(pstdev(v), SD[k] * 1.0)


def rule_alerts(rows, day):
    out = []
    for k in LABEL:
        m, sd = baseline(rows, k)
        cur = rows[day - 1][k]
        z = (cur - m) / sd
        lo, hi = LIMITS.get(k, (None, None))
        if (lo is not None and cur < lo) or (hi is not None and cur > hi):
            out.append({"engine": "A", "metric": k, "severity": "critical", "risk": RISK[k],
                        "message": f"{LABEL[k]} {cur:.1f} outside configured limit (baseline {m:.1f} +/- {sd:.1f}) on day {day}"})
            continue
        bad = -z if k in LOW_BAD else z
        last3 = [r[k] for r in rows[max(0, day - 3):day]]
        tr = last3[-1] - last3[0]
        worse = tr < 0 if k in LOW_BAD else tr > 0
        if bad >= 2 and (worse or bad >= 3):
            out.append({"engine": "A", "metric": k, "severity": "critical" if bad >= 3.5 else "warning",
                        "message": f"{LABEL[k]} {cur:.1f} vs baseline {m:.1f} +/- {sd:.1f} (z={z:.1f}) on day {day}",
                        "risk": RISK[k]})
    keys = {a["metric"] for a in out}
    if len(keys & {"hr", "spo2", "co2"}) >= 2:
        out.insert(0, {"engine": "A", "metric": "combo", "severity": "critical", "risk": "Hypoxia + closed environment",
                       "message": "HR up, SpO2 down and cabin CO2 high: possible hypoxia/hypercapnia exposure"})
    if len(keys & {"sleep", "mood", "stress"}) >= 2:
        out.insert(0, {"engine": "A", "metric": "combo", "severity": "critical", "risk": "Behavioral changes + sleep",
                       "message": "Poor sleep, lower mood, higher stress: possible isolation strain"})
    return out


def anomaly_findings(rows, day):
    out = []
    if day <= BASE_DAYS:
        return out
    for k in ("hr", "sleep", "mood", "stress", "ex"):
        n = min(5, day)
        y = [r[k] for r in rows[day - n:day]]
        xm, ym = (n - 1) / 2, mean(y)
        slope = sum((i - xm) * (v - ym) for i, v in enumerate(y)) / sum((i - xm) ** 2 for i in range(n))
        _, sd = baseline(rows, k)
        drift = slope * (n - 1) / sd
        bad = -drift if k in LOW_BAD else drift
        if bad >= 3:
            out.append({"engine": "B", "metric": k, "slope_per_day": round(slope, 2), "data_points": [round(v, 2) for v in y],
                        "confidence": round(min(.95, .4 + bad / 10), 2),
                        "explanation": "5-day slope far exceeds normal day-to-day variation. Confidence is pattern strength, not a diagnosis probability.",
                        "risk": RISK[k]})
    return out

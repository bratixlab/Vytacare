"""Simulated astronaut data (14 mission days). Replace with wearable or device feeds later."""
import random

METRICS = ["hr", "sys", "temp", "spo2", "glu", "sleep", "mood", "stress", "ex", "co2", "rad"]
SD = {"hr": 1.5, "sys": 3, "temp": .12, "spo2": .4, "glu": 4, "sleep": .3, "mood": .5, "stress": .5, "ex": 10, "co2": 120, "rad": 30}

ASTRONAUTS = [
    {"id": "A", "name": "Cdr. Amara Okafor", "seed": 11, "scenario": "Nominal",
     "base": {"hr": 62, "sys": 116, "temp": 36.6, "spo2": 98, "glu": 92, "sleep": 7.2, "mood": 7.8, "stress": 3, "ex": 120, "co2": 2800, "rad": 480}},
    {"id": "B", "name": "Dr. Li Wei", "seed": 22, "scenario": "Isolation drift", "from": 8,
     "drift": {"sleep": -.45, "mood": -.5, "stress": .55, "ex": -9, "hr": .9},
     "base": {"hr": 66, "sys": 118, "temp": 36.7, "spo2": 98, "glu": 91, "sleep": 7.0, "mood": 7.5, "stress": 3.5, "ex": 110, "co2": 2750, "rad": 470}},
    {"id": "C", "name": "Maj. Sam Ortega", "seed": 33, "scenario": "Cabin air", "from": 10,
     "drift": {"spo2": -.55, "hr": 1.8, "co2": 380, "sys": 1.6},
     "base": {"hr": 64, "sys": 117, "temp": 36.6, "spo2": 97.8, "glu": 93, "sleep": 7.1, "mood": 7.6, "stress": 3.2, "ex": 115, "co2": 2780, "rad": 490}},
]


def readings_for(a: dict, days: int = 14) -> list[dict]:
    r = random.Random(a["seed"])
    rows = []
    for d in range(1, days + 1):
        row = {}
        for k in METRICS:
            v = a["base"][k] + (r.random() + r.random() + r.random() - 1.5) * 1.6 * SD[k]
            if a.get("drift") and k in a["drift"] and d >= a["from"]:
                v += a["drift"][k] * (d - a["from"] + 1)
            row[k] = v
        row["spo2"] = min(100, row["spo2"])
        row["mood"] = max(1, min(10, row["mood"]))
        row["stress"] = max(1, min(10, row["stress"]))
        rows.append(row)
    return rows

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .engine import anomaly_findings, rule_alerts
from .simulator import ASTRONAUTS, readings_for

app = FastAPI(title="ASTRAVYTA API", version="0.1.0",
              description="Research prototype. Simulated data. Not a diagnostic system.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SYNCED: dict[str, dict] = {}   # prototype store. Replace with PostgreSQL (see db/schema.sql)


class SyncRecord(BaseModel):
    id: str
    astronaut: str
    day: int
    severity: str
    message: str
    createdAt: str


class SyncBatch(BaseModel):
    records: list[SyncRecord]


def _find(aid: str) -> dict:
    for a in ASTRONAUTS:
        if a["id"] == aid:
            return a
    raise HTTPException(404, "Unknown astronaut")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/astronauts")
def astronauts():
    return [{"id": a["id"], "name": a["name"], "scenario": a["scenario"]} for a in ASTRONAUTS]


@app.get("/api/astronauts/{aid}/readings")
def readings(aid: str):
    return readings_for(_find(aid))


@app.get("/api/astronauts/{aid}/analysis")
def analysis(aid: str, day: int = 14):
    rows = readings_for(_find(aid))
    if not 1 <= day <= len(rows):
        raise HTTPException(422, "day out of range")
    return {"day": day, "engine_a": rule_alerts(rows, day), "engine_b": anomaly_findings(rows, day)}


@app.post("/api/sync")
def sync(batch: SyncBatch):
    """Idempotent sync. Same id + same content is a duplicate; same id + different content is kept as a conflict."""
    accepted = duplicates = conflicts = 0
    for r in batch.records:
        data = r.model_dump()
        if r.id not in SYNCED:
            SYNCED[r.id] = data
            accepted += 1
        elif SYNCED[r.id] == data:
            duplicates += 1
        else:
            SYNCED[f"{r.id}#conflict-{len(SYNCED)}"] = data
            conflicts += 1
    return {"accepted": accepted, "duplicates": duplicates, "conflicts": conflicts}
